"""\
skeleton tests package

To run all tests type 'python runalltests.py'
"""
