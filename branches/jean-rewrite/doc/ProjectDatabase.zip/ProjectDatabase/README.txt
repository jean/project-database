Draft implementation of project database:

- One project definition for all project types;

- Dependencies - MXM Contacts, ATReferenceBrowserWidget, ATExtensions.

- Create an index called getTitle that indexes title field -> necessary for the search to work.
